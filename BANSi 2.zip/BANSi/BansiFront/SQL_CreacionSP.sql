USE BdiExamen;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE spAgregar 
@id int, @nombre varchar(255), @descripcion varchar(255)
AS 
BEGIN TRY
  INSERT INTO tblExamen(idExamen, Nombre, Descripcion) VALUES (@id, @nombre, @descripcion)
  SELECT 0 ErrorNumber, 'Registro insertado satisfactoriamente' ErrorMessage 
END TRY
BEGIN CATCH
  SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_MESSAGE() AS ErrorMessage;
END CATCH;

CREATE PROCEDURE spActualizar
@id int, @nombre varchar(255), @descripcion varchar(255)
AS 
BEGIN TRY
	IF (SELECT COUNT(*) FROM tblExamen WHERE idExamen = @id ) = 0
		BEGIN
		SELECT -1 ErrorNumber, 'No existe el ID.' ErrorMessage 
		END
	ELSE
		BEGIN
		UPDATE tblExamen SET Nombre = @nombre, Descripcion = @descripcion WHERE idExamen = @id
		SELECT 0 ErrorNumber, 'Registro actualizado satisfactoriamente.' ErrorMessage 
		END
END TRY
BEGIN CATCH
  SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_MESSAGE() AS ErrorMessage;
END CATCH;


CREATE PROCEDURE spEliminar
@id int
AS 
BEGIN TRY
	IF (SELECT COUNT(*) FROM tblExamen WHERE idExamen = @id ) = 0
		BEGIN
		SELECT -1 ErrorNumber, 'No existe el ID.' ErrorMessage 
		END
	ELSE
		BEGIN
		DELETE FROM tblExamen WHERE idExamen = @id
		SELECT 0 ErrorNumber, 'Registro eliminado satisfactoriamente.' ErrorMessage 
		END
END TRY
BEGIN CATCH
  SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_MESSAGE() AS ErrorMessage;
END CATCH;


CREATE PROCEDURE spConsultar 
@nombre varchar(255), @descripcion varchar(255)
AS 
BEGIN TRY
  SELECT * FROM tblExamen WHERE Nombre LIKE '%' + @nombre + '%' AND Descripcion LIKE '%' + @descripcion + '%'  
END TRY
BEGIN CATCH
  SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_MESSAGE() AS ErrorMessage;
END CATCH;


--exec spAgregar 0,'Nombre 0', 'Descripcion 0'
--exec spAgregar 6,'N3', 'D3'

--exec spActualizar 0,'Nombre cero', 'Descripcion cero'
--exec spActualizar 10,'Nombre uno', 'Descripcion uno'

--exec spConsultar 'nombre 1', ''
--exec spConsultar 10

--exec spEliminar 0
--exec spEliminar 10

