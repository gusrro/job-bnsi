﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BansiFrontEntrada
{
  public partial class FrmApp : Form
  {
    string Conn;
    string UrlWS;

    public FrmApp()
    {
      InitializeComponent();
    }

    #region METODOS

    private void Aceptar()
    {
      try
      {
        ClsExamen cls = new ClsExamen(RdoWS.Checked);
        cls.connDb = Conn;
        cls.urlWS = UrlWS;

        int.TryParse(TxtId.Text, out int id);
        string nombre = TxtNombre.Text;
        string descripcion = TxtDescripcion.Text;
        string Error = "";
        bool retorno = false;

        LblMsg.Text = "";
        switch (GpoEditar.Text)
        {
          case "CONSULTAR":
            Grid.DataSource = cls.ConsultarExamen(nombre, descripcion, out Error);
            if (Error == "0 - GET CORRECTO") Error = "Consulta correcta";
            LblMsg.Text = Error;
            break;

          case "AGREGAR":
            retorno = cls.AgregarExamen(id, nombre, descripcion, out Error);
            LblMsg.Text = retorno == true ? "Agregado correctamente" : Error;
            Grid.DataSource = cls.ConsultarExamen("", "", out Error);
            break;

          case "ACTUALIZAR":
            retorno = cls.ActualizarExamen(id, nombre, descripcion, out Error);
            LblMsg.Text = retorno == true ? "Actualizado correctamente" : Error;
            Grid.DataSource = cls.ConsultarExamen("", "", out Error);
            break;

          case "ELIMINAR":
            DialogResult result = MessageBox.Show("¿Desea continuar con la eliminación del registro?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.No) break;

            retorno = cls.EliminarExamen(id, out Error);
            LblMsg.Text = retorno == true ? "Eliminado correctamente" : Error;
            Grid.DataSource = cls.ConsultarExamen("", "", out Error);
            break;
        }
      }
      catch (Exception ex)
      {
        LblMsg.Text = ex.HResult + "-" + ex.Message;
      }
    }

    private void Limpiar()
    {
      LblId.Enabled = true;
      TxtId.Enabled = true;
      TxtId.Text = "";
      TxtNombre.Text = "";
      TxtDescripcion.Text = "";
      TxtId.Focus();
    }
      
    private void Menu_Consultar()
    {
      this.BackColor = Color.LightBlue;
      StatusStrip1.BackColor = this.BackColor;
      GpoEditar.Text = "CONSULTAR";
      Limpiar();
      LblId.Enabled = false;
      TxtId.Enabled = false;
      TxtId.Text = "";
      Grid.DataSource = null;
    }

    private void Menu_Agregar()
    {
      this.BackColor = Color.LightGreen;
      StatusStrip1.BackColor = this.BackColor;
      GpoEditar.Text = "AGREGAR";
      Limpiar();
    }

    private void Menu_Actualizar()
    {
      this.BackColor = Color.LightYellow;
      StatusStrip1.BackColor = this.BackColor;
      GpoEditar.Text = "CONSULTAR";
      Limpiar();
      Aceptar();
      GpoEditar.Text = "ACTUALIZAR";
      LblId.Enabled = false;
      TxtId.Enabled = false;
    }

    private void Menu_Eliminar()
    {
      this.BackColor = Color.LightSalmon;
      StatusStrip1.BackColor = this.BackColor;
      GpoEditar.Text = "CONSULTAR";
      Limpiar();
      Aceptar();
      GpoEditar.Text = "ELIMINAR";
      LblId.Enabled = false;
      TxtId.Enabled = false;
    }

    #endregion

    private void FrmApp_Load(object sender, EventArgs e)
    {

    }

    private void FrmApp_Shown(object sender, EventArgs e)
    {
      Conn = @"Data Source=" + TxtServidor.Text + ";Integrated Security=true;Initial Catalog = BdiExamen;";
      UrlWS = TxtURL.Text;
      Menu_Consultar();
    }

    private void BtnAceptar_Click(object sender, EventArgs e)
    {
      Aceptar();
    }

    private void MenuAgregar_Click(object sender, EventArgs e)
    {
      Menu_Agregar();
    }

    private void MenuConsultar_Click(object sender, EventArgs e)
    {
      Menu_Consultar();
    }

    private void MenuActualizar_Click(object sender, EventArgs e)
    {
      Menu_Actualizar();
    }

    private void MenuEliminar_Click(object sender, EventArgs e)
    {
      Menu_Eliminar();
    }

    private void MenuSalir_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void Grid_SelectionChanged(object sender, EventArgs e)
    {
      try
      {
        if(GpoEditar.Text == "ACTUALIZAR" || GpoEditar.Text == "ELIMINAR")
        {
          TxtId.Text = Grid.CurrentRow.Cells[0].Value.ToString();
          TxtNombre.Text = Grid.CurrentRow.Cells[1].Value.ToString();
          TxtDescripcion.Text = Grid.CurrentRow.Cells[2].Value.ToString();
        }
      }
      catch
      {
        
      }
    }

    private void Grid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
    {
      if (e.RowIndex % 2 == 0)
        e.CellStyle.BackColor = Color.LightSkyBlue;
    }
  }
}
