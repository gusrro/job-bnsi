﻿
namespace BansiFrontEntrada
{
  partial class FrmApp
  {
    /// <summary>
    /// Variable del diseñador necesaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Limpiar los recursos que se estén usando.
    /// </summary>
    /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Código generado por el Diseñador de Windows Forms

    /// <summary>
    /// Método necesario para admitir el Diseñador. No se puede modificar
    /// el contenido de este método con el editor de código.
    /// </summary>
    private void InitializeComponent()
    {
      this.LblId = new System.Windows.Forms.Label();
      this.TxtId = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.TxtNombre = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.TxtDescripcion = new System.Windows.Forms.TextBox();
      this.GpoEditar = new System.Windows.Forms.GroupBox();
      this.BtnAceptar = new System.Windows.Forms.Button();
      this.RdoWS = new System.Windows.Forms.RadioButton();
      this.RdoSP = new System.Windows.Forms.RadioButton();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.MenuConsultar = new System.Windows.Forms.ToolStripMenuItem();
      this.MenuAgregar = new System.Windows.Forms.ToolStripMenuItem();
      this.MenuActualizar = new System.Windows.Forms.ToolStripMenuItem();
      this.MenuEliminar = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
      this.MenuSalir = new System.Windows.Forms.ToolStripMenuItem();
      this.Grid = new System.Windows.Forms.DataGridView();
      this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
      this.LblMsg = new System.Windows.Forms.ToolStripStatusLabel();
      this.label1 = new System.Windows.Forms.Label();
      this.TxtServidor = new System.Windows.Forms.TextBox();
      this.label4 = new System.Windows.Forms.Label();
      this.TxtURL = new System.Windows.Forms.TextBox();
      this.GpoEditar.SuspendLayout();
      this.menuStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.Grid)).BeginInit();
      this.StatusStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // LblId
      // 
      this.LblId.AutoSize = true;
      this.LblId.Location = new System.Drawing.Point(11, 27);
      this.LblId.Name = "LblId";
      this.LblId.Size = new System.Drawing.Size(19, 17);
      this.LblId.TabIndex = 0;
      this.LblId.Text = "Id";
      // 
      // TxtId
      // 
      this.TxtId.Location = new System.Drawing.Point(99, 27);
      this.TxtId.Name = "TxtId";
      this.TxtId.Size = new System.Drawing.Size(61, 22);
      this.TxtId.TabIndex = 2;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(11, 58);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(58, 17);
      this.label2.TabIndex = 0;
      this.label2.Text = "Nombre";
      // 
      // TxtNombre
      // 
      this.TxtNombre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.TxtNombre.Location = new System.Drawing.Point(99, 55);
      this.TxtNombre.MaxLength = 255;
      this.TxtNombre.Name = "TxtNombre";
      this.TxtNombre.Size = new System.Drawing.Size(573, 22);
      this.TxtNombre.TabIndex = 3;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(11, 83);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(82, 17);
      this.label3.TabIndex = 0;
      this.label3.Text = "Descripción";
      // 
      // TxtDescripcion
      // 
      this.TxtDescripcion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.TxtDescripcion.Location = new System.Drawing.Point(99, 83);
      this.TxtDescripcion.MaxLength = 255;
      this.TxtDescripcion.Name = "TxtDescripcion";
      this.TxtDescripcion.Size = new System.Drawing.Size(573, 22);
      this.TxtDescripcion.TabIndex = 4;
      // 
      // GpoEditar
      // 
      this.GpoEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.GpoEditar.Controls.Add(this.BtnAceptar);
      this.GpoEditar.Controls.Add(this.RdoWS);
      this.GpoEditar.Controls.Add(this.TxtId);
      this.GpoEditar.Controls.Add(this.TxtDescripcion);
      this.GpoEditar.Controls.Add(this.RdoSP);
      this.GpoEditar.Controls.Add(this.LblId);
      this.GpoEditar.Controls.Add(this.label3);
      this.GpoEditar.Controls.Add(this.label2);
      this.GpoEditar.Controls.Add(this.TxtNombre);
      this.GpoEditar.Location = new System.Drawing.Point(13, 122);
      this.GpoEditar.Name = "GpoEditar";
      this.GpoEditar.Size = new System.Drawing.Size(678, 226);
      this.GpoEditar.TabIndex = 1;
      this.GpoEditar.TabStop = false;
      // 
      // BtnAceptar
      // 
      this.BtnAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.BtnAceptar.BackColor = System.Drawing.Color.DodgerBlue;
      this.BtnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.BtnAceptar.Location = new System.Drawing.Point(14, 148);
      this.BtnAceptar.Name = "BtnAceptar";
      this.BtnAceptar.Size = new System.Drawing.Size(658, 57);
      this.BtnAceptar.TabIndex = 7;
      this.BtnAceptar.Text = "Aceptar";
      this.BtnAceptar.UseVisualStyleBackColor = false;
      this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
      // 
      // RdoWS
      // 
      this.RdoWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.RdoWS.AutoSize = true;
      this.RdoWS.Location = new System.Drawing.Point(567, 111);
      this.RdoWS.Name = "RdoWS";
      this.RdoWS.Size = new System.Drawing.Size(105, 21);
      this.RdoWS.TabIndex = 6;
      this.RdoWS.Text = "WebService";
      this.RdoWS.UseVisualStyleBackColor = true;
      // 
      // RdoSP
      // 
      this.RdoSP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.RdoSP.AutoSize = true;
      this.RdoSP.Checked = true;
      this.RdoSP.Location = new System.Drawing.Point(429, 111);
      this.RdoSP.Name = "RdoSP";
      this.RdoSP.Size = new System.Drawing.Size(132, 21);
      this.RdoSP.TabIndex = 5;
      this.RdoSP.TabStop = true;
      this.RdoSP.Text = "Store procedure";
      this.RdoSP.UseVisualStyleBackColor = true;
      // 
      // menuStrip1
      // 
      this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuConsultar,
            this.MenuAgregar,
            this.MenuActualizar,
            this.MenuEliminar,
            this.toolStripMenuItem1,
            this.MenuSalir});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(700, 28);
      this.menuStrip1.TabIndex = 3;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // MenuConsultar
      // 
      this.MenuConsultar.BackColor = System.Drawing.Color.LightBlue;
      this.MenuConsultar.Name = "MenuConsultar";
      this.MenuConsultar.Size = new System.Drawing.Size(85, 24);
      this.MenuConsultar.Text = "Consultar";
      this.MenuConsultar.Click += new System.EventHandler(this.MenuConsultar_Click);
      // 
      // MenuAgregar
      // 
      this.MenuAgregar.BackColor = System.Drawing.Color.LightGreen;
      this.MenuAgregar.Name = "MenuAgregar";
      this.MenuAgregar.Size = new System.Drawing.Size(77, 24);
      this.MenuAgregar.Text = "Agregar";
      this.MenuAgregar.Click += new System.EventHandler(this.MenuAgregar_Click);
      // 
      // MenuActualizar
      // 
      this.MenuActualizar.BackColor = System.Drawing.Color.LightYellow;
      this.MenuActualizar.Name = "MenuActualizar";
      this.MenuActualizar.Size = new System.Drawing.Size(89, 24);
      this.MenuActualizar.Text = "Actualizar";
      this.MenuActualizar.Click += new System.EventHandler(this.MenuActualizar_Click);
      // 
      // MenuEliminar
      // 
      this.MenuEliminar.BackColor = System.Drawing.Color.LightSalmon;
      this.MenuEliminar.Name = "MenuEliminar";
      this.MenuEliminar.Size = new System.Drawing.Size(77, 24);
      this.MenuEliminar.Text = "Eliminar";
      this.MenuEliminar.Click += new System.EventHandler(this.MenuEliminar_Click);
      // 
      // toolStripMenuItem1
      // 
      this.toolStripMenuItem1.Name = "toolStripMenuItem1";
      this.toolStripMenuItem1.Size = new System.Drawing.Size(27, 24);
      this.toolStripMenuItem1.Text = "|";
      // 
      // MenuSalir
      // 
      this.MenuSalir.BackColor = System.Drawing.Color.Orange;
      this.MenuSalir.Name = "MenuSalir";
      this.MenuSalir.Size = new System.Drawing.Size(52, 24);
      this.MenuSalir.Text = "Salir";
      this.MenuSalir.Click += new System.EventHandler(this.MenuSalir_Click);
      // 
      // Grid
      // 
      this.Grid.AllowUserToAddRows = false;
      this.Grid.AllowUserToDeleteRows = false;
      this.Grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.Grid.Location = new System.Drawing.Point(13, 354);
      this.Grid.Name = "Grid";
      this.Grid.ReadOnly = true;
      this.Grid.RowHeadersWidth = 51;
      this.Grid.RowTemplate.Height = 24;
      this.Grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.Grid.Size = new System.Drawing.Size(675, 297);
      this.Grid.TabIndex = 8;
      this.Grid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.Grid_CellFormatting);
      this.Grid.SelectionChanged += new System.EventHandler(this.Grid_SelectionChanged);
      // 
      // StatusStrip1
      // 
      this.StatusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblMsg});
      this.StatusStrip1.Location = new System.Drawing.Point(0, 666);
      this.StatusStrip1.Name = "StatusStrip1";
      this.StatusStrip1.Size = new System.Drawing.Size(700, 26);
      this.StatusStrip1.TabIndex = 9;
      // 
      // LblMsg
      // 
      this.LblMsg.Name = "LblMsg";
      this.LblMsg.Size = new System.Drawing.Size(15, 20);
      this.LblMsg.Text = "_";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(10, 52);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(81, 17);
      this.label1.TabIndex = 10;
      this.label1.Text = "Servidor bd";
      // 
      // TxtServidor
      // 
      this.TxtServidor.Location = new System.Drawing.Point(97, 52);
      this.TxtServidor.Name = "TxtServidor";
      this.TxtServidor.Size = new System.Drawing.Size(588, 22);
      this.TxtServidor.TabIndex = 11;
      this.TxtServidor.Text = "GEQC-0067\\SQLEXPRESS";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(10, 83);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(62, 17);
      this.label4.TabIndex = 10;
      this.label4.Text = "URL WS";
      // 
      // TxtURL
      // 
      this.TxtURL.Location = new System.Drawing.Point(97, 80);
      this.TxtURL.Name = "TxtURL";
      this.TxtURL.Size = new System.Drawing.Size(588, 22);
      this.TxtURL.TabIndex = 11;
      this.TxtURL.Text = "https://localhost:44333/api/tblExamen";
      // 
      // FrmApp
      // 
      this.AcceptButton = this.BtnAceptar;
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(700, 692);
      this.Controls.Add(this.TxtURL);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.TxtServidor);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.StatusStrip1);
      this.Controls.Add(this.Grid);
      this.Controls.Add(this.GpoEditar);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "FrmApp";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "BANSi";
      this.Load += new System.EventHandler(this.FrmApp_Load);
      this.Shown += new System.EventHandler(this.FrmApp_Shown);
      this.GpoEditar.ResumeLayout(false);
      this.GpoEditar.PerformLayout();
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.Grid)).EndInit();
      this.StatusStrip1.ResumeLayout(false);
      this.StatusStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label LblId;
    private System.Windows.Forms.TextBox TxtId;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox TxtNombre;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox TxtDescripcion;
    private System.Windows.Forms.GroupBox GpoEditar;
    private System.Windows.Forms.Button BtnAceptar;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem MenuAgregar;
    private System.Windows.Forms.ToolStripMenuItem MenuActualizar;
    private System.Windows.Forms.ToolStripMenuItem MenuEliminar;
    private System.Windows.Forms.ToolStripMenuItem MenuConsultar;
    private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    private System.Windows.Forms.ToolStripMenuItem MenuSalir;
    private System.Windows.Forms.RadioButton RdoSP;
    private System.Windows.Forms.RadioButton RdoWS;
    private System.Windows.Forms.DataGridView Grid;
    private System.Windows.Forms.StatusStrip StatusStrip1;
    private System.Windows.Forms.ToolStripStatusLabel LblMsg;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox TxtServidor;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.TextBox TxtURL;
  }
}

