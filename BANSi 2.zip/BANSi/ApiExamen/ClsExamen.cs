﻿using System;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using RestSharp;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Web;

namespace BansiFrontEntrada
{
  public class ClsExamen
  {
    public string connDb;
    public string urlWS;
    private string Err = "";
    private DataTable dt;
    private bool usarWebService; // Parámetro para configurar el método de trabajo

    // Constructor que recibe el parámetro para configurar el método de trabajo
    public ClsExamen(bool usarWebService)
    {
      this.usarWebService = usarWebService;
    }

    private class Items
    {
      public int IdExamen { get; set; }
      public string Nombre { get; set; }
      public string Descripcion { get; set; }
    }

    #region METODOS

    public DataTable ConsultarExamen(string nombre, string descripcion, out string Error)
    {
      try
      {
        dt = usarWebService ? ConsultarWS(nombre, descripcion, out Err) : ConsultarSP(nombre, descripcion, out Err);
        Error = Err;
        return dt;
      }
      catch (Exception Ex)
      {
        Error = Ex.HResult + "-" + Ex.Message;
        return null;
      }
    }

    public bool AgregarExamen(int id, string nombre, string descripcion, out string Error)
    {
      try
      {
        bool result = usarWebService ? AgregarWS(id, nombre, descripcion, out Err) : AgregarSP(id, nombre, descripcion, out Err);
        Error = Err;
        return result;
      }
      catch (Exception Ex)
      {
        Error = Ex.HResult.ToString() + '-' + Ex.Message;
        return false;
      }
    }

    public bool ActualizarExamen(int id, string nombre, string descripcion, out string Error)
    {
      try
      {
        bool result = usarWebService ? ActualizarWS(id, nombre, descripcion, out Err) : ActualizarSP(id, nombre, descripcion, out Err);
        Error = Err;
        return result;
      }
      catch (Exception ex)
      {
        Error = ex.HResult.ToString() + '-' + ex.Message;
        return false;
      }
    }

    public bool EliminarExamen(int id, out string Error)
    {
      try
      {
        bool result = usarWebService ? EliminarWS(id, out Err) : EliminarSP(id, out Err);
        Error = Err;
        return result;
      }
      catch (Exception Ex)
      {
        Error = Ex.HResult.ToString() + '-' + Ex.Message;
        return false;
      }
    }
    
    #endregion

    #region METODOS Store Procedure

    private DataTable ConsultarSP(string nombre, string descripcion, out string Err)
    {
      string storedProcedureName = "spConsultar";

      using (SqlConnection connection = new SqlConnection(connDb))
      {
        using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
        {
          command.CommandType = CommandType.StoredProcedure;
          command.Parameters.AddWithValue("@nombre", nombre);
          command.Parameters.AddWithValue("@descripcion", descripcion);
          try
          {
            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            Err = "0 - Registro consultado satisfactoriamente";
            return dt;
          }
          catch (Exception ex)
          {
            Err = ex.HResult.ToString() + " - " + ex.Message;
            throw ex;
          }
        }
      }
    }

    private bool AgregarSP(int id, string nombre, string descripcion, out string Err)
    {
      if (id < 1) //Validaciones
      {
        Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
        return false;
      }

      string storedProcedureName = "spAgregar";
      using (SqlConnection connection = new SqlConnection(connDb))
      {
        connection.Open();
        SqlTransaction transaction = connection.BeginTransaction();

        try
        {
          SqlCommand command = new SqlCommand(storedProcedureName, connection, transaction);
          command.CommandType = CommandType.StoredProcedure;
          command.Parameters.AddWithValue("@id", id);
          command.Parameters.AddWithValue("@nombre", nombre);
          command.Parameters.AddWithValue("@descripcion", descripcion);

          int filasAfectadas = command.ExecuteNonQuery();
          if (filasAfectadas > 0)
          {
            transaction.Commit();
            Err = "0 - Registro agregado satisfactoriamente";
            return true;
          }
          else
          {
            Err = "1 - Registro no agregado";
            transaction.Rollback();
            return false;
          }
        }
        catch (Exception ex)
        {
          transaction.Rollback();
          Err = ex.HResult.ToString() + " - " + ex.Message;
          return false;
        }
      }

    }

    private bool ActualizarSP(int id, string nombre, string descripcion, out string Err)
    {
      if (id < 1) //Validaciones
      {
        Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
        return false;
      }

      string storedProcedureName = "spActualizar";
      using (SqlConnection connection = new SqlConnection(connDb))
      {
        connection.Open();
        SqlTransaction transaction = connection.BeginTransaction();

        try
        {
          SqlCommand command = new SqlCommand(storedProcedureName, connection, transaction);
          command.CommandType = CommandType.StoredProcedure;
          command.Parameters.AddWithValue("@id", id);
          command.Parameters.AddWithValue("@nombre", nombre);
          command.Parameters.AddWithValue("@descripcion", descripcion);
          
          int filasAfectadas = command.ExecuteNonQuery();
          if (filasAfectadas > 0)
          {
            transaction.Commit();
            Err = "0 - Registro actualizado satisfactoriamente";
            return true;
          }
          else
          {
            Err = "1 - Registro no actualizado";
            transaction.Rollback();
            return false;
          }
        }
        catch (Exception ex)
        {
          // En caso de error, hacer rollback de la transacción
          transaction.Rollback();
          Err = ex.HResult.ToString() + " - " + ex.Message;
          return false;
        }
      }

    }

    private bool EliminarSP(int id, out string Err)
    {
      if (id < 1) //Validaciones
      {
        Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
        return false;
      }

      string storedProcedureName = "spEliminar";
      using (SqlConnection connection = new SqlConnection(connDb))
      {
        connection.Open();
        SqlTransaction transaction = connection.BeginTransaction();

        try
        {
          SqlCommand command = new SqlCommand(storedProcedureName, connection, transaction);
          command.CommandType = CommandType.StoredProcedure;
          command.Parameters.AddWithValue("@id", id);
          
          int filasAfectadas = command.ExecuteNonQuery();
          if (filasAfectadas > 0)
          {
            transaction.Commit();
            Err = "0 - Registro eliminado satisfactoriamente";
            return true;
          }
          else
          {
            // Rollback si no se eliminó ninguna fila
            Err = "1 - Registro no eliminado";
            transaction.Rollback();
            return false;
          }
        }
        catch (Exception ex)
        {
          // En caso de error, hacer rollback de la transacción
          transaction.Rollback();
          Err = ex.HResult.ToString() + " - " + ex.Message;
          return false;
        }
      }

    }

    #endregion

    #region METODOS Web Service

    private DataTable BANSiPost(string url, string metodo, string json, out string Err, string autorizacion = null)
    {
      try
      {
        var client = new RestClient(url);
        var request = new RestRequest();
        switch (metodo.ToUpper())
        {
          case "POST":
            request.Method = Method.Post;
            break;
          case "PUT":
            request.Method = Method.Put;
            break;
          case "DELETE":
            request.Method = Method.Delete;
            break;
        }

        request.AddHeader("content-type", "application/json");
        request.AddParameter("application/json", json, ParameterType.RequestBody);

        if (autorizacion != null)
        {
          request.AddHeader("Authorization", autorizacion);
        }
        var response = client.Execute(request);
        DataTable dt = (DataTable)JsonConvert.DeserializeObject(response.Content, (typeof(DataTable)));
        Err = "0 - POST CORRECTO";
        return dt;
      }
      catch (Exception ex)
      {
        Err = ex.HResult.ToString() + " - " + ex.Message;
        return null;
      }
    }
    private DataTable BANSiGet(string url, out string Err)
    {
      try
      {
        HttpWebRequest myWebRequest = (HttpWebRequest)WebRequest.Create(url);
        myWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0";
        //myWebRequest.CookieContainer = myCookie;
        myWebRequest.Credentials = CredentialCache.DefaultCredentials;
        myWebRequest.Proxy = null;
        HttpWebResponse myHttpWebResponse = (HttpWebResponse)myWebRequest.GetResponse();
        Stream myStream = myHttpWebResponse.GetResponseStream();
        StreamReader myStreamReader = new StreamReader(myStream);
        //Leemos los datos
        string Datos = HttpUtility.HtmlDecode(myStreamReader.ReadToEnd());
        //dynamic data = JsonConvert.DeserializeObject(Datos);
        DataTable dt = (DataTable)JsonConvert.DeserializeObject(Datos, (typeof(DataTable)));
        Err = "0 - GET CORRECTO";
        return dt;
      }
      catch(Exception Ex)
      {
        Err = (Ex.HResult.ToString() + " - " + Ex.Message).ToUpper();
        return null;
      }
     
    }

    private DataTable ConsultarWS(string nombre, string descripcion, out string Err)
    {
      DataTable dtReturn;
      string Error;

      try
      {
        dt = BANSiGet(urlWS, out Error);
        if (Error == "0") Error = "0 - Registro consultado satisfactoriamente";
        var Consulta = dt.AsEnumerable()
         .Where(row => row.Field<string>("Nombre").Contains(nombre) && row.Field<string>("Descripcion").Contains(descripcion));
        dtReturn = Consulta.CopyToDataTable();
      }
      catch(Exception ex)
      {
        Error = ex.HResult + " - " + ex.Message;
        dtReturn = null;
      }
      
      Err = Error;
      return dtReturn;
    }

    private bool AgregarWS(int id, string nombre, string descripcion, out string Err)
    {
      try
      {
        if (id < 1) //Validaciones
        {
          Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
          return false;
        }

        var item = new Items();
        item.IdExamen = id;
        item.Nombre = nombre;
        item.Descripcion = descripcion;
        string raw = System.Text.Json.JsonSerializer.Serialize(item);
        dt = BANSiPost(urlWS, "POST", raw, out string Error);
        if (Error == "0") Error = "0 - Registro agregado satisfactoriamente";

        Err = Error;
        return true;
      }
      catch(Exception ex)
      {
        Err = ex.HResult + "-" + ex.Message;
        return false;
      }
     
    }

    private bool ActualizarWS(int id, string nombre, string descripcion, out string Err)
    {
      try
      {
        if (id < 1) //Validaciones
        {
          Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
          return false;
        }

        var item = new Items();
        item.IdExamen = id;
        item.Nombre = nombre;
        item.Descripcion = descripcion;
        string raw = System.Text.Json.JsonSerializer.Serialize(item);
        dt = BANSiPost(urlWS + "/" + id, "PUT", raw, out string Error);
        if (Error == "0") Error = "0 - Registro actualizado satisfactoriamente";

        Err = Error;
        return true;
      }
      catch(Exception ex)
      {
        Err = ex.HResult + "-" + ex.Message;
        return false;
      }
    }

    private bool EliminarWS(int id, out string Err)
    {
      try
      {
        if (id < 1) //Validaciones
        {
          Err = "-1 Error. El Id debe ser de tipo entero mayor a cero";
          return false;
        }

        var item = new Items();
        item.IdExamen = id;

        string raw = System.Text.Json.JsonSerializer.Serialize(item);
        dt = BANSiPost(urlWS + "/" + id, "DELETE", raw, out string Error);
        if (Error == "0") Error = "0 - Registro eliminado satisfactoriamente";

        Err = Error;
        return true;
      }
      catch(Exception ex)
      {
        Err = ex.HResult + "-" + ex.Message;
        return false;
      }
     
    }

    #endregion

  }

}
